OpenTeam attachment QA. Inert fixture; no user data.
